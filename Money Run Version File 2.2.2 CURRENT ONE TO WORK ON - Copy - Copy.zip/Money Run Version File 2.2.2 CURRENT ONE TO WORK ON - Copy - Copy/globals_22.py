levels = {}
world = None

DARK_GREY = (50,50,50)
BLACK = (0, 0, 0)