# name this Utilities and stuff idk
import pygame
import engine_copy22
import globals_22

#-----------------------------------------------------------------use function to draw text

DARK_GREY = (50,50,50)
DARK_GREEN = (2, 48, 32)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
LIGHT_BLUE = (173, 216, 230)
pygame.font.init()
font = pygame.font.Font(pygame.font.get_default_font(), 24)


def drawText(screen, t, x, y): 
    text = font.render(t, True, GREEN)
    text_rectangle = text.get_rect()
    text_rectangle.topleft = (x, y)
    screen.blit(text, text_rectangle)

runner_lives = pygame.image.load('runner.png')

money0 = pygame.image.load('money_0.png')
money1 = pygame.image.load('money_1.png')
money2 = pygame.image.load('money_2.png')
money3 = pygame.image.load('money_3.png')        
money4 = pygame.image.load('money_4.png')

def makeMoney(x, y):
    entity = engine_copy22.Entity()
    entity.position = engine_copy22.Position(x, y, 32, 32)
    entityAnimation = engine_copy22.Animation([money0, money1, money2, money3, money4,])
    #entity.animations = engine_copy22.Animations()
    entity.animations.add('idle', entityAnimation)
    entity.type = 'collectable'
    return entity

enemy0 = pygame.image.load('police_standing.png')

def makeEnemy(x, y):
    entity = engine_copy22.Entity()
    entity.position = engine_copy22.Position(x, y, 25, 25)
    entityAnimation = engine_copy22.Animation([enemy0])
    #entity.animations = engine_copy22.Animations()
    entity.animations.add('idle', entityAnimation)
    entity.type = 'dangerous'
    return entity


idle0 = pygame.image.load('runner_side.png')
idle1 = pygame.image.load('runner_side_idle_0.png')


walking0 = pygame.image.load('runner_side.png')
walking1 = pygame.image.load('runner_walking_0.png')
walking2 = pygame.image.load('runner_walking_1.png')
walking3 = pygame.image.load('runner_walking_2.png')

def makePlayer(x, y):
    entity = engine_copy22.Entity()
    entity.position = engine_copy22.Position(x, y, 32, 32)
    entityIdleAnimation = engine_copy22.Animation([idle0, idle1,])
    entityWalkingAnimation = engine_copy22.Animation([walking0, walking1, walking2, walking3])
    #entity.animations = engine_copy22.Animations()
    entity.animations.add('idle', entityIdleAnimation)
    entity.animations.add('walking', entityWalkingAnimation)
    entity.type = 'player'
    return entity


        
        

