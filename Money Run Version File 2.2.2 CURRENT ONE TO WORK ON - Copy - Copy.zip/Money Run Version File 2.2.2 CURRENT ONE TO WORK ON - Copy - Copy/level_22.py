

class Level:
    def __init__(self, platforms = None, entities = None, winFunc = None, loseFunc = None): #None optional hiiii
        self.platforms = platforms
        self.entities = entities
        self.winFunc = winFunc    #line 5 line 6 storing function rather than calling (obvousis at this point but just leavin that there)
        self.loseFunc = loseFunc 
    def isWon(self):
        if self.winFunc is None:
            return False
        return self.winFunc(self)
    def isLost(self):
        if self.loseFunc is None:
            return False
        return self.loseFunc(self)
    
    
        #.... 