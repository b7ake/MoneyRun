#Code from Dino Platform game by Rik Cross
#MOST CODE IS IS ALL FROM DINO VIDEO BY RIK CROSS. SPRITES ARE ALL MADE FROM ME.
#12:57
#Blake Citro
#CST119

#dino sprite by me
#egg (collectable) by me
#money in newer versions by me
#en sprite made by me
#
import level_22
import pygame
import time
import sys
import engine_copy22 #import <file name> can import code from another file
import utils_22
import scene_22
import globals_22

    
#---------------------------------------------------------------constant variables
SCREEN_SIZE = (700, 500) 
DARK_GREY = (50,50,50)
MUD = (83, 69, 57) 
GREEN = (0, 255, 0)

player_direction = 'right'


#---------------------------------------------------------------------------init
pygame.init()
screen = pygame.display.set_mode(SCREEN_SIZE)
pygame.display.set_caption('Blake\'s Platform Game')
clock = pygame.time.Clock()


# game state//win//lose
game_state = 'playing'

entities = []

#--------------------------------------------------------------player

player_speed = 0
player_acceleration = 0.2


"""the walking animation is little slow to my liking 
but it works the way i want it too, maybe find code to speed it up..... 
or not........ yk you'll find out in the future"""
""" on the flip side, no cropping needed everything still on platform jajajaja"""

#--------------------------------------------------------------------------------------------
money1 = utils_22.makeMoney(525, 222)
money2 = utils_22.makeMoney(100, 222)


enemy = utils_22.makeEnemy(500,222)
enemy.camera = engine_copy22.Camera(422, 10, 220, 220)  ####(general thingy, 100, 100 is the size of the camera. 550, 10 is the positioning (i will forget this so i documeting ykyk) )
enemy.camera.setWorldPos(500, 222)
enemy.score = engine_copy22.Score()


player = utils_22.makePlayer(300,0)
player.camera = engine_copy22.Camera(10, 10, 400, 400) #camera attatched to player - draws the camera for the player
player.camera.setWorldPos(300,0)
player.camera.trackEntity(player)
player.score = engine_copy22.Score()
player.battle = engine_copy22.Battle()
entities.append(player)

#cameraSys = engine_copy22.CameraSystem()

#lose if no players have lives remaning 
def lostLevel(level):
    # level isnt lost if any player has a life left
    for entity in level.entities:
        if entity.type == 'player':
            if entity.battle is not None:
                if entity.battle.lives > 0:
                    return False #false means level is not lost
    #level i lost otherwise
    return True

#win if no collectalbe items left
def wonLevel(level):
    #level isnt won if any collectable exist
    for entity in level.entities:
        if entity.type == 'collectable':
            return False          
    #level isnt won otherwise
    return True





globals_22.levels[1] = level_22.Level(
    platforms = [
        #middle
        pygame.Rect(250,300, 175, 25),
        #left
        pygame.Rect(50, 250, 150, 25),
        #right
        pygame.Rect(475,250, 150, 25)
    ],
    entities = [
        player, enemy, money1, money2

    ],
    winFunc = wonLevel,
    loseFunc = lostLevel          #functions to check if you win or lose videionarenjlhraiol
)



globals_22.levels[2] = level_22.Level(
    platforms = [
        #middle
        pygame.Rect(250,300, 175, 25),
    ],
    entities = [
        player, money1

    ],
    winFunc = wonLevel,
    loseFunc = lostLevel
)

#################set current level
globals_22.world = globals_22.levels[1]

sceneManager = scene_22.SceneManager()  #create scene      #file.class - yk
mainMenu = scene_22.MainMenuScene()  #create one scene
sceneManager.push(mainMenu) #push scene in scene manager


#----------------------------------------------------------------------game loop
running = True 
while running:

    if sceneManager.isEmpty():
        running = False
    sceneManager.input()
    sceneManager.update()
    sceneManager.draw(screen)

    #-----
    #INPUT
    #-----
    
    #check for quit
    for event in pygame.event.get():
        #print(event)
        if event.type == pygame.QUIT:
        #if event.type == 12: #Exist button at top of pygame window
            running = False #when 12 for Exit button is clicked, loop will stop. Easier to use pygame.QUIT 
    if game_state == 'playing':
        
        new_player_x = player.position.rect.x
        new_player_y = player.position.rect.y

        #player input
        keys = pygame.key.get_pressed()
        #----------------------------double picture to make dino look left and right when moving, left and right.-----------------------------------------
        # a = left
        if keys[pygame.K_a]:
            new_player_x -= 2
            player.direction = 'left'
            player.state = 'walking'
            #player_image = pygame.image.load('dino (left).xcf')
       
        # d = right
        if keys[pygame.K_d]:
            new_player_x += 2
            player.direction = 'right'
            player.state = 'walking'
            #player_image = pygame.image.load('dino (right).xcf')
        
        if not keys[pygame.K_a] and not keys[pygame.K_d]:
            player.state = 'idle'
        
        # w = jump (if on the ground)
        if keys[pygame.K_w] and player_on_ground:
            player_speed = -5
        
        # control zoom level of the player camera
        #zoom in 
        if keys[pygame.K_q]:
            player.camera.zoomLevel -= 0.01
        
        #zoom in
        if keys[pygame.K_e]:
             player.camera.zoomLevel += 0.01
        
        
        #check level hiiiiiiiiiiiiiiiiiii hiii
        #print(player.camera.zoomLevel)



        #check for state
        #print(player_state)

        

    #-------------------------------------------------------------------update
    if game_state =='playing':
        
    #---------------------------------------------------------------update eMONEYNONBETY anmateioin eifewojf
        for entity in entities:
            entity.animations.animationList[entity.state].update()

        
    #-----------------------------------------------------------------------------------------------------------------horizontal movement
        
        new_player_rect = pygame.Rect(new_player_x, player.position.rect.y, player.position.rect.width, player.position.rect.height)
        x_collision = False

        #check against every platform
        for p in globals_22.world.platforms:
            if p.colliderect(new_player_rect):
                x_collision = True
                break
        

        if x_collision == False:
            player.position.rect.x = new_player_x 

        #----------------------------------------vertical movement
        player_speed += player_acceleration
        new_player_y += player_speed

        new_player_rect = pygame.Rect(int(player.position.rect.x), int(new_player_y) ,player.position.rect.width, player.position.rect.height)
        y_collision = False
        player_on_ground = False 

        #...check against every platform
        for p in globals_22.world.platforms:
            if p.colliderect(new_player_rect):
                y_collision = True
                player_speed = 0
                if p[1] > new_player_y:
                    # stick the player to platform
                    player.position.rect.y = p[1] - player.position.rect.height
                    player_on_ground = True
                
                break
        

        if y_collision == False:
            player.position.rect.y = int(new_player_y)


        #see if any coins have been collected
        player_rect = pygame.Rect(int(player.position.rect.x), int(player.position.rect.y), player.position.rect.width, player.position.rect.height)
         
        #-------------collection system ------------------------------------------------------------------------------------------
        for entity in globals_22.world.entities:
            if entity.type == 'collectable':
                if entity.position.rect.colliderect(player_rect):
                    globals_22.world.entities.remove(entity)
                    player.score.score +=1
                    

        # enemy system ------------------------------ bad guys danger stuff but awesomemerrrrrr
        for entity in globals_22.world.entities:
            if entity.type == 'dangerous': #-Like a check the enemy only works on entities if the type is dangerous same for collectable
                if entity.position.rect.colliderect(player_rect):
                    player.battle.lives -= 1
                    #resert player position
                    player.position.rect.x = 300
                    player.position.rect.y = 0
                    player_speed = 0
                    

        #if player were to fall out of BOUNDS!!

        if player.position.rect.x >= 700:
            player.battle.lives -= 1
            player.position.rect.x = 300
            player.position.rect.y = 0
            player_speed = 0
            if player.battle.lives <= 0:
                    game_state = 'lose'

        if player.position.rect.y>= 500:
            player.battle.lives -= 1
            player.position.rect.x = 300
            player.position.rect.y = 0
            player_speed = 0
            if player.battle.lives <= 0:
                    game_state = 'lose'

 
    #if world.isWon():
       # game_state = 'win'
    #if world.isLost():
        #game_state = 'lose'
    #--------------------------------------------
    #DRAW
    #--------------------------------------------

    #cameraSys.update(screen, world)
    
    #if game_state =='playing':


        clock.tick(60) 
#quit
pygame.quit()
